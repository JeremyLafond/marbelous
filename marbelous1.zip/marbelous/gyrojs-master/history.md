0.1.0 (beta) / 21-August-2011
==================

	* Removing jquery dependacy
	* renaming to gyro.js from jGyro

0.0.1 (alpha) / 26-July-2011 
==================

  * Inital Version
